<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\DB;
use App\Models\Role;

class AuthController extends Controller
{
    // POST /api/auth/register
    public function register(Request $request)
    {
        $data = $request->validate([
            'name'     => ['required', 'string', 'max:255'],
            'email'    => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', Rules\Password::defaults()],
        ]);

        return DB::transaction(function () use ($data) {
            $user = User::create([
                'name'     => $data['name'],
                'email'    => $data['email'],
                'password' => Hash::make($data['password']),
            ]);

            $role = Role::where('name', 'user')->first();
            if (!$role) {
                // transaction will rollback automatically by throwing
                abort(response()->json([
                    'status'  => false,
                    'message' => 'Registration failed: default role "user" not found.',
                ], 422));
            }

            // 👇 IMPORTANT: pass an ARRAY (id or name), not the Role model
            $user->syncRoles([$role->id]); // or: $user->syncRoles([$role->name]);

            // double-check it actually attached
            if (!$user->roles()->where('roles.id', $role->id)->exists()) {
                abort(response()->json([
                    'status'  => false,
                    'message' => 'Registration failed: unable to assign default role.',
                ], 422));
            }

            $token = $user->createToken('mobile')->plainTextToken;

            return response()->json([
                'status'  => true,
                'message' => 'Registered successfully.',
                'token'   => $token,
                'user'    => new UserResource($user->load('roles')),
            ], 201);
        });
    }

    // POST /api/auth/login
    public function login(Request $request)
    {
        $data = $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $data['email'])->first();

        if (! $user || ! Hash::check($data['password'], $user->password)) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid credentials.',
            ], 422);
        }

        // Revoke old tokens if you prefer single-session mobile logins
        // $user->tokens()->delete();

        $token = $user->createToken('mobile')->plainTextToken;

        return response()->json([
            'status'  => true,
            'message' => 'Logged in successfully.',
            'token'   => $token,
            'user'    => new UserResource($user), // includes roles & permissions
        ]);
    }

    // POST /api/auth/logout
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'status'  => true,
            'message' => 'Logged out.',
        ]);
    }

    // POST /api/auth/logout-all
    public function logoutAll(Request $request)
    {
        $request->user()->tokens()->delete();

        return response()->json([
            'status'  => true,
            'message' => 'Logged out from all devices.',
        ]);
    }

    // GET /api/auth/me
    public function me(Request $request)
    {
        return response()->json([
            'status' => true,
            'user'   => new UserResource($request->user()),
        ]);
    }
}
