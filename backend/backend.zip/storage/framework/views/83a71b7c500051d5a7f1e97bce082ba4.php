<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Multipurpose, super flexible, powerful, clean modern responsive bootstrap 5 admin template">
    <meta name="keywords"
        content="admin template, ki-admin admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="la-themes">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/images/logo/favicon.png')); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/logo/favicon.png')); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard '); ?></title>

    <!-- Animation css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animation/animate.min.css')); ?>">
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">


    <!-- Flag Icon css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/flag-icons-master/flag-icon.css')); ?>">
    <!-- Tabler icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/tabler-icons/tabler-icons.css')); ?>">
    <!-- Apexcharts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.css')); ?>">
    <!-- Glightbox -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/glightbox/glightbox.min.css')); ?>">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.min.css')); ?>">
    <!-- Simplebar -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/simplebar/simplebar.css')); ?>">
    <!-- App css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <div class="app-wrapper">
        <div class="loader-wrapper">
            <div class="loader_24"></div>
        </div>

        <!-- Sidebar Navigation -->
        <?php echo $__env->make('layouts.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Main Content -->
        <div class="app-content">
            <!-- Header -->
            <?php echo $__env->make('layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Content -->
            <main>
                <div class="container-fluid">

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>

            <!-- Footer -->
            <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <!-- Scroll to top -->
        <div class="go-top">
            <span class="progress-value"><i class="ti ti-chevron-up"></i></span>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/simplebar/simplebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/phosphor/phosphor.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/glightbox/glightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/customizer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/ecommerce_dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: <?php echo json_encode(session('success'), 15, 512) ?>,
                timer: 2000,
                showConfirmButton: false
            });
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: <?php echo json_encode(session('error'), 15, 512) ?>
            });
        </script>
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>