

<?php $__env->startSection('content'); ?>

<div class="row m-1">
    <div class="col-12">
        <h5>Tasks Management</h5>
        <ul class="app-line-breadcrumbs mb-3">
            <li><a class="f-s-14 f-w-500" href="#"><i class="ph-duotone ph-lock f-s-16"></i>Tasks</a></li>
            <li class="active"><a class="f-s-14 f-w-500" href="#">Tasks list</a></li>
        </ul>
    </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="mb-0">Tasks</h5>

    
    <?php if (app('laratrust')->hasPermission('tasks.create')) : ?>
      <button class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#createForm">
        + Add Task
      </button>
    <?php endif; // app('laratrust')->permission ?>
  </div>

  
  <?php if (app('laratrust')->hasPermission('tasks.create')) : ?>
  <div id="createForm" class="collapse border-top p-3">
    <form method="POST" action="<?php echo e(route('tasks.store')); ?>" class="row g-2">
      <?php echo csrf_field(); ?>
      <div class="col-md-3">
        <input name="title" class="form-control" placeholder="Title" required>
      </div>
      <div class="col-md-4">
        <input name="description" class="form-control" placeholder="Description">
      </div>
      <div class="col-md-2">
        <select name="status" class="form-select">
          <option value="todo">To-Do</option>
          <option value="in_progress">In-Progress</option>
          <option value="done">Done</option>
        </select>
      </div>
      <div class="col-md-2">
        <select name="assigned_to" class="form-select">
          <option value="">Unassigned</option>
          <?php $__currentLoopData = \App\Models\User::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-1">
        <button class="btn btn-success w-100">Save</button>
      </div>
    </form>
  </div>
  <?php endif; // app('laratrust')->permission ?>

  
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead>
        <tr>
          <th>#</th><th>Title</th><th>Status</th><th>Assignee</th><th>Created By</th><th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($t->title); ?></td>
          <td><span class="badge text-bg-secondary"><?php echo e(ucfirst(str_replace('_',' ',$t->status))); ?></span></td>
          <td><?php echo e($t->assignee?->name ?? '—'); ?></td>
          <td><?php echo e($t->creator?->name); ?></td>
          <td class="text-end">
            
            <?php if (app('laratrust')->hasPermission('tasks.update')) : ?>
            <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#edit-<?php echo e($t->id); ?>">Edit</button>
            <?php endif; // app('laratrust')->permission ?>

            
            <?php if (app('laratrust')->hasPermission('tasks.delete')) : ?>
            <form action="<?php echo e(route('tasks.destroy',$t)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this task?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-danger">Delete</button>
            </form>
            <?php endif; // app('laratrust')->permission ?>
          </td>
        </tr>

        
        <?php if (app('laratrust')->hasPermission('tasks.update')) : ?>
        <tr id="edit-<?php echo e($t->id); ?>" class="collapse">
          <td colspan="6">
            <form method="POST" action="<?php echo e(route('tasks.update',$t)); ?>" class="row g-2">
              <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
              <div class="col-md-3">
                <input name="title" class="form-control" value="<?php echo e($t->title); ?>" required>
              </div>
              <div class="col-md-4">
                <input name="description" class="form-control" value="<?php echo e($t->description); ?>">
              </div>
              <div class="col-md-2">
                <select name="status" class="form-select">
                  <?php $__currentLoopData = ['todo','in_progress','done']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php if($t->status===$s): echo 'selected'; endif; ?>><?php echo e(ucfirst(str_replace('_',' ',$s))); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-2">
                <select name="assigned_to" class="form-select">
                  <option value="">Unassigned</option>
                  <?php $__currentLoopData = \App\Models\User::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->id); ?>" <?php if($t->assigned_to===$u->id): echo 'selected'; endif; ?>><?php echo e($u->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="col-md-1">
                <button class="btn btn-primary ">Update</button>
              </div>
            </form>
          </td>
        </tr>
        <?php endif; // app('laratrust')->permission ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <div class="card-footer">
    <?php echo e($tasks->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/tasks/index.blade.php ENDPATH**/ ?>