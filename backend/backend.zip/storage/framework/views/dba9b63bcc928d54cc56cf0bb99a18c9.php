
<?php $__env->startSection('content'); ?>

<div class="row m-1">
    <div class="col-12">
        <h5>Edit Role Permissions</h5>
        <ul class="app-line-breadcrumbs mb-3">
            <li><a class="f-s-14 f-w-500" href="<?php echo e(route('roles.index')); ?>"><i class="ph-duotone ph-lock f-s-16"></i> Roles</a></li>
            <li class="active"><a class="f-s-14 f-w-500" href="#">Edit Permissions</a></li>
        </ul>
    </div>
</div>

<div class="col-xl-12">
    <div class="card">
        <div class="card-header">
            <h5>Manage Permissions for <span class="text-primary"><?php echo e(ucfirst($role->name)); ?></span></h5>
            <p class="text-muted mb-0">Select permissions to assign to this role.</p>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-2">
                            <div class="form-check">
                                <input class="form-check-input"
                                       type="checkbox"
                                       name="permissions[]"
                                       value="<?php echo e($permission->id); ?>"
                                       id="perm-<?php echo e($permission->id); ?>"
                                       <?php echo e(in_array($permission->id, $rolePermissions) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="perm-<?php echo e($permission->id); ?>">
                                    <?php echo e($permission->display_name ?? ucfirst($permission->name)); ?>

                                </label>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/admin/role/edit.blade.php ENDPATH**/ ?>