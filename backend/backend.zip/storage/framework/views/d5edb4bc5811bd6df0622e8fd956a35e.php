
<?php $__env->startSection('content'); ?>

<div class="row m-1">
    <div class="col-12">
        <h5>Roles & Permissions</h5>
        <ul class="app-line-breadcrumbs mb-3">
            <li><a class="f-s-14 f-w-500" href="#"><i class="ph-duotone ph-lock f-s-16"></i> Access Control</a></li>
            <li class="active"><a class="f-s-14 f-w-500" href="#">Roles</a></li>
        </ul>
    </div>
</div>

<div class="col-xl-12">
    <div class="card">
        <div class="card-header">
            <h5>Manage Roles & Permissions</h5>
            <p class="text-muted mb-0">Edit permission access for Manager and User roles.</p>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Role Name</th>
                            <th>Display Name</th>
                            <th>Permissions Count</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(ucfirst($role->name)); ?></td>
                                <td><?php echo e($role->display_name ?? ucfirst($role->name)); ?></td>
                                <td><?php echo e($role->permissions->count()); ?></td>
                                <td>
                                    <?php if($role->name !== 'super-admin'): ?>
                                        <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-sm btn-primary">
                                            Edit Permissions
                                        </a>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Locked</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/admin/role/index.blade.php ENDPATH**/ ?>