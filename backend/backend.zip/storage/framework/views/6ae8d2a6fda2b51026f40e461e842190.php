<?php ($user = $user ?? auth()->user()); ?>

<section>
    <h3 class="h4 fw-bold mb-2">Profile Information</h3>
    <p class="text-muted mb-3">Update your account's profile information and email address.</p>

    <form id="send-verification" method="POST" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
    </form>

    <form method="POST" action="<?php echo e(route('profile.update')); ?>" class="mt-3">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input id="name" name="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name" autofocus>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input id="email" name="email" type="email"
                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email', $user->email)); ?>"
                required autocomplete="username">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$user->hasVerifiedEmail()): ?>
            <div class="alert alert-warning d-flex justify-content-between align-items-center">
                <div>Your email address is unverified.</div>
                <button form="send-verification" class="btn btn-sm btn-outline-primary">Resend verification
                    email</button>
            </div>
            <?php if(session('status') === 'verification-link-sent'): ?>
                <div class="alert alert-success mt-2">
                    A new verification link has been sent to your email address.
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-primary">Save</button>
            <?php if(session('status') === 'profile-updated'): ?>
                <span class="text-success">Saved.</span>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>