
<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb start -->
   <div class="row m-1">
    <div class="col-12">
        <h5>User Management</h5>
        <ul class="app-line-breadcrumbs mb-3">
            <li>
                <a class="f-s-14 f-w-500" href="#">
                    <span>
                        <i class="ph-duotone ph-users-three f-s-16"></i> Users
                    </span>
                </a>
            </li>
            <li class="active">
                <a class="f-s-14 f-w-500" href="#">User List</a>
            </li>
        </ul>
    </div>
</div>

    <!-- Breadcrumb end -->
    <div class="col-xl-12">
        <div class="card">
            <div class="card-header">
                <h5>User List</h5>
                <p style="margin-top: 8px">Below is the complete list of system users with their assigned roles and current
                    status.</p>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bottom-border table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   <td><?php echo e($loop->iteration); ?></td>

                                    
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <p class="mb-0 f-w-500"><?php echo e($user->name); ?></p>
                                        </div>
                                    </td>

                                    
                                    <td><?php echo e($user->email ?? '—'); ?></td>

                                    
                                    <td>
                                        <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <span class="badge bg-info me-1">
                                                <?php echo e($role->display_name ?? ucfirst($role->name)); ?>

                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-muted">No role</span>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td>
                                        <span
                                            class="badge text-light-primary"><?php echo e($user->is_active ?? true ? 'active' : 'inactive'); ?></span>
                                    </td>

                                    
                                    <td><?php echo e(optional($user->created_at)->format('d M, Y') ?? '—'); ?></td>

                                    
                                    <td class="text-nowrap">
                                        
                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                            class="btn btn-sm btn-primary">Edit</a>

                                        
                                        <?php if(!$user->hasRole('super-admin')): ?>
                                            <button type="button" class="btn btn-sm btn-danger delete-btn"
                                                data-id="<?php echo e($user->id); ?>">
                                                Delete
                                            </button>

                                            <form id="delete-form-<?php echo e($user->id); ?>"
                                                action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST"
                                                style="display:none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function () {
            const userId = this.dataset.id;

            Swal.fire({
                title: 'Are you sure?',
                text: "This action will permanently delete the user.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + userId).submit();
                }
            });
        });
    });
});
</script>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/admin/users/index.blade.php ENDPATH**/ ?>