<!-- Header Section starts -->
          <header class="header-main">
            <div class="container-fluid">
              <div class="row">
                <div
                  class="col-8 col-sm-6 d-flex align-items-center header-left p-0"
                >
                  <span class="header-toggle">
                    <i class="ph ph-squares-four"></i>
                  </span>

                  <div class="header-searchbar w-100">
                    <form action="#" class="mx-sm-3 app-form app-icon-form">
                      <div class="position-relative">
                        <input
                          aria-label="Search"
                          class="form-control"
                          placeholder="Search..."
                          type="search"
                        />
                       <i class="bi bi-search text-dark"></i>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </header>
          <!-- Header Section ends --><?php /**PATH C:\Users\Lenovo\role-based-access-api\backend\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>