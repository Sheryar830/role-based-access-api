<!-- Footer Section starts-->
      <footer>
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-9 col-12">
              <p class="footer-text f-w-600 mb-0">
               Copyright © 2025 Shery. All rights reserved 💖
              </p>
            </div>
            <div class="col-md-3">
              <div class="footer-text text-end"></div>
            </div>
          </div>
        </div>
      </footer>
      <!-- Footer Section ends-->